package kr.co.sist.sec.dto;

public class DTOSubjectScore {
	
	private String opencourse_name;
	private String opencourse_period;
	private String opensubject_period;
	private String opensubject_name;
	private String classroom_name;
	private String teacher_name;
	private String student_name;
	private String textbook_name;
	
	
	public String getOpencourse_name() {
		return opencourse_name;
	}
	public void setOpencourse_name(String opencourse_name) {
		this.opencourse_name = opencourse_name;
	}
	public String getOpencourse_period() {
		return opencourse_period;
	}
	public void setOpencourse_period(String opencourse_period) {
		this.opencourse_period = opencourse_period;
	}
	public String getOpensubject_period() {
		return opensubject_period;
	}
	public void setOpensubject_period(String opensubject_period) {
		this.opensubject_period = opensubject_period;
	}
	public String getOpensubject_name() {
		return opensubject_name;
	}
	public void setOpensubject_name(String opensubject_name) {
		this.opensubject_name = opensubject_name;
	}
	public String getClassroom_name() {
		return classroom_name;
	}
	public void setClassroom_name(String classroom_name) {
		this.classroom_name = classroom_name;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getTextbook_name() {
		return textbook_name;
	}
	public void setTextbook_name(String textbook_name) {
		this.textbook_name = textbook_name;
	}
	
	
	
	
}
