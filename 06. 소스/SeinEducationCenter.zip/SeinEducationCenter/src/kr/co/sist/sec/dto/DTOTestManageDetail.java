package kr.co.sist.sec.dto;

public class DTOTestManageDetail {
	
	private String course_subject;
	private String course_start_date;
	private String testfile_ox;
	private String score_ox;
	
	public String getCourse_subject() {
		return course_subject;
	}
	
	public void setCourse_subject(String course_subject) {
		this.course_subject = course_subject;
	}
	
	public String getTestfile_ox() {
		return testfile_ox;
	}
	
	public void setTestfile_ox(String testfile_ox) {
		this.testfile_ox = testfile_ox;
	}
	
	public String getScore_ox() {
		return score_ox;
	}
	
	public void setScore_ox(String score_ox) {
		this.score_ox = score_ox;
	}

	public String getCourse_start_date() {
		return course_start_date;
	}

	public void setCourse_start_date(String course_start_date) {
		this.course_start_date = course_start_date;
	}
	
	
	
	
	
}
