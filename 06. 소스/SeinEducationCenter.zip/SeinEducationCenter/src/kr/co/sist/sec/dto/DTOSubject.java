package kr.co.sist.sec.dto;

public class DTOSubject {
	private String seq;
	private String name;
	private String text_seq;
	private String status;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getText_seq() {
		return text_seq;
	}
	public void setText_seq(String text_seq) {
		this.text_seq = text_seq;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
