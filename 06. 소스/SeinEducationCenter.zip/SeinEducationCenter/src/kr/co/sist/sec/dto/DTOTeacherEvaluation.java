package kr.co.sist.sec.dto;

public class DTOTeacherEvaluation {
	
	private String seq;
	private String complete;
	private String plan_score;
	private String content_score;
	private String communication_score;
	private String benefit_score;
	private String satisfaction_score;
	private String suggestion;
	private String opencoursestudent_seq;
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getComplete() {
		return complete;
	}
	public void setComplete(String complete) {
		this.complete = complete;
	}
	public String getPlan_score() {
		return plan_score;
	}
	public void setPlan_score(String plan_score) {
		this.plan_score = plan_score;
	}
	public String getContent_score() {
		return content_score;
	}
	public void setContent_score(String content_score) {
		this.content_score = content_score;
	}
	public String getCommunication_score() {
		return communication_score;
	}
	public void setCommunication_score(String communication_score) {
		this.communication_score = communication_score;
	}
	public String getBenefit_score() {
		return benefit_score;
	}
	public void setBenefit_score(String benefit_score) {
		this.benefit_score = benefit_score;
	}
	public String getSatisfaction_score() {
		return satisfaction_score;
	}
	public void setSatisfaction_score(String satisfaction_score) {
		this.satisfaction_score = satisfaction_score;
	}
	public String getSuggestion() {
		return suggestion;
	}
	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}
	public String getOpencoursestudent_seq() {
		return opencoursestudent_seq;
	}
	public void setOpencoursestudent_seq(String opencoursestudent_seq) {
		this.opencoursestudent_seq = opencoursestudent_seq;
	}
	

	
}
