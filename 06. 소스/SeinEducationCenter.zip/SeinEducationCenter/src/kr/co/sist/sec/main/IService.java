package kr.co.sist.sec.main;

public interface IService {


}
