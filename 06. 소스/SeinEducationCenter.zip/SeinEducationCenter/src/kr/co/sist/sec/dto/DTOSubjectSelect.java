package kr.co.sist.sec.dto;

public class DTOSubjectSelect {
	
	private String subject_seq;
	private String subject_name;

	public String getSubject_name() {
		return subject_name;
	}

	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}

	public String getSubject_seq() {
		return subject_seq;
	}

	public void setSubject_seq(String subject_seq) {
		this.subject_seq = subject_seq;
	}
	
	
	
}
