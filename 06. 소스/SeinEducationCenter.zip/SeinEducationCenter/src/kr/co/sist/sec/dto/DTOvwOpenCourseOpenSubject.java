package kr.co.sist.sec.dto;

public class DTOvwOpenCourseOpenSubject {
	private String osseq;
	private String osopencourse_seq;
	private String oscoursesubject_seq;
	private String osstart_date;
	private String osend_date;
	private String oswrittentest_date;
	private String osperformancetest_date;
	private String cscourse_seq;
	private String cssubject_seq;
	private String stext_seq;
	private String sname;
	private String sstatus;
	
	public String getOsseq() {
		return osseq;
	}
	public void setOsseq(String osseq) {
		this.osseq = osseq;
	}
	public String getOsopencourse_seq() {
		return osopencourse_seq;
	}
	public void setOsopencourse_seq(String osopencourse_seq) {
		this.osopencourse_seq = osopencourse_seq;
	}
	public String getOscoursesubject_seq() {
		return oscoursesubject_seq;
	}
	public void setOscoursesubject_seq(String oscoursesubject_seq) {
		this.oscoursesubject_seq = oscoursesubject_seq;
	}
	public String getOsstart_date() {
		return osstart_date;
	}
	public void setOsstart_date(String osstart_date) {
		this.osstart_date = osstart_date;
	}
	public String getOsend_date() {
		return osend_date;
	}
	public void setOsend_date(String osend_date) {
		this.osend_date = osend_date;
	}
	public String getOswrittentest_date() {
		return oswrittentest_date;
	}
	public void setOswrittentest_date(String oswrittentest_date) {
		this.oswrittentest_date = oswrittentest_date;
	}
	public String getOsperformancetest_date() {
		return osperformancetest_date;
	}
	public void setOsperformancetest_date(String osperformancetest_date) {
		this.osperformancetest_date = osperformancetest_date;
	}
	public String getCscourse_seq() {
		return cscourse_seq;
	}
	public void setCscourse_seq(String cscourse_seq) {
		this.cscourse_seq = cscourse_seq;
	}
	public String getCssubject_seq() {
		return cssubject_seq;
	}
	public void setCssubject_seq(String cssubject_seq) {
		this.cssubject_seq = cssubject_seq;
	}
	public String getStext_seq() {
		return stext_seq;
	}
	public void setStext_seq(String stext_seq) {
		this.stext_seq = stext_seq;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSstatus() {
		return sstatus;
	}
	public void setSstatus(String sstatus) {
		this.sstatus = sstatus;
	}
	
	
}
