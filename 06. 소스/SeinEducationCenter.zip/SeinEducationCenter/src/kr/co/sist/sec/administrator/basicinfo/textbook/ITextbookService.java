package kr.co.sist.sec.administrator.basicinfo.textbook;

public interface ITextbookService {

	void list();

	void search();

	void add();

	void edit();

	void del();

}
