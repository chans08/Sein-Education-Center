package kr.co.sist.sec.administrator.basicinfo.classroom;

public interface IClassroomService {

	void list();

	void search();

	void add();

	void del();

}
