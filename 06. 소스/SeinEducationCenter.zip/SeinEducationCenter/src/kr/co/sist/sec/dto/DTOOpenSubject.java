package kr.co.sist.sec.dto;

public class DTOOpenSubject {
	private String seq;
	private String opencourse_seq;
	private String coursesubject_seq;
	private String start_date;
	private String end_date;
	private String writtentest_date;
	private String performancetest_date;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getOpencourse_seq() {
		return opencourse_seq;
	}
	public void setOpencourse_seq(String opencourse_seq) {
		this.opencourse_seq = opencourse_seq;
	}
	public String getCoursesubject_seq() {
		return coursesubject_seq;
	}
	public void setCoursesubject_seq(String coursesubject_seq) {
		this.coursesubject_seq = coursesubject_seq;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getWrittentest_date() {
		return writtentest_date;
	}
	public void setWrittentest_date(String writtentest_date) {
		this.writtentest_date = writtentest_date;
	}
	public String getPerformancetest_date() {
		return performancetest_date;
	}
	public void setPerformancetest_date(String performancetest_date) {
		this.performancetest_date = performancetest_date;
	}
	
	
}
