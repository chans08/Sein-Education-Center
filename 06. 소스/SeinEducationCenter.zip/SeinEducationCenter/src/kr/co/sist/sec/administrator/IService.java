package kr.co.sist.sec.administrator;

public interface IService {

	void login(int n);

	void findId(int n);

	void findPw(int n);

}
