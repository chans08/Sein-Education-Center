package kr.co.sist.sec.dto;

public class DTOCompany {
	
	private String seq;
	private String name;
	private String scale;
	private String employee_num;
	private String established_year;
	private String area;
	
	
	public String getSeq() {
		return seq;
	}
	
	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getScale() {
		return scale;
	}
	
	public void setScale(String scale) {
		this.scale = scale;
	}
	
	public String getEmployee_num() {
		return employee_num;
	}
	
	public void setEmployee_num(String employee_num) {
		this.employee_num = employee_num;
	}
	
	public String getEstablished_year() {
		return established_year;
	}
	
	public void setEstablished_year(String established_year) {
		this.established_year = established_year;
	}
	
	public String getArea() {
		return area;
	}
	
	public void setArea(String area) {
		this.area = area;
	}
	
}
