package kr.co.sist.sec.dto;

public class DTOPersonalScoreDetail {

	private String student_name;
	private String opensubject_name;
	private String opensubject_period;
	private String teacher_name;
	private String attendance;
	private String written_test;
	private String performance_test;
	
	
	public String getOpensubject_name() {
		return opensubject_name;
	}
	public void setOpensubject_name(String opensubject_name) {
		this.opensubject_name = opensubject_name;
	}
	public String getOpensubject_period() {
		return opensubject_period;
	}
	public void setOpensubject_period(String opensubject_period) {
		this.opensubject_period = opensubject_period;
	}
	public String getTeacher_name() {
		return teacher_name;
	}
	public void setTeacher_name(String teacher_name) {
		this.teacher_name = teacher_name;
	}
	public String getAttendance() {
		return attendance;
	}
	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}
	public String getWritten_test() {
		return written_test;
	}
	public void setWritten_test(String written_test) {
		this.written_test = written_test;
	}
	public String getPerformance_test() {
		return performance_test;
	}
	public void setPerformance_test(String performance_test) {
		this.performance_test = performance_test;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	
	
	
}
