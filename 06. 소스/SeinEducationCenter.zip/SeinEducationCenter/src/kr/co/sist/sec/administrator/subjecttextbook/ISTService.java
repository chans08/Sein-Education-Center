package kr.co.sist.sec.administrator.subjecttextbook;

public interface ISTService {
	void list();

	void add();

	void del();

}
