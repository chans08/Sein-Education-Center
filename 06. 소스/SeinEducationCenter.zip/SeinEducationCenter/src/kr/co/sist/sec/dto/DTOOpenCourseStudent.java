package kr.co.sist.sec.dto;

public class DTOOpenCourseStudent {
	
	private String seq;
	private String student_seq;
	private String opencourse_seq;
	private String status;
	
	
	public String getSeq() {
		return seq;
	}
	
	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	public String getStudent_seq() {
		return student_seq;
	}
	
	public void setStudent_seq(String student_seq) {
		this.student_seq = student_seq;
	}
	
	public String getOpencourse_seq() {
		return opencourse_seq;
	}
	
	public void setOpencourse_seq(String opencourse_seq) {
		this.opencourse_seq = opencourse_seq;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
}
