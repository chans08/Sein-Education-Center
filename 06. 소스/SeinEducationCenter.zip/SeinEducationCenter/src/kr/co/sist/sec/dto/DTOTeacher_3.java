package kr.co.sist.sec.dto;

public class DTOTeacher_3 {

	private String Course_seq;
	private String Student_seq;
	private String Student_name;
	private String Status_status;
	private String Geuntae_geuntae_date;
	
	public String getCourse_seq() {
		return Course_seq;
	}
	public void setCourse_seq(String course_seq) {
		Course_seq = course_seq;
	}
	public String getStudent_seq() {
		return Student_seq;
	}
	public void setStudent_seq(String student_seq) {
		Student_seq = student_seq;
	}
	public String getStudent_name() {
		return Student_name;
	}
	public void setStudent_name(String student_name) {
		Student_name = student_name;
	}
	public String getStatus_status() {
		return Status_status;
	}
	public void setStatus_status(String status_status) {
		Status_status = status_status;
	}
	public String getGeuntae_geuntae_date() {
		return Geuntae_geuntae_date;
	}
	public void setGeuntae_geuntae_date(String geuntae_geuntae_date) {
		Geuntae_geuntae_date = geuntae_geuntae_date;
	}

	

}
